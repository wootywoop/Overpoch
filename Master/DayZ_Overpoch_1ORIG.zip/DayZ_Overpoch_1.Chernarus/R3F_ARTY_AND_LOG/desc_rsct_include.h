#include "R3F_ARTY_disable_enable.sqf"

#ifdef R3F_ARTY_enable
#include "R3F_ARTY\dlg_artilleur\dlg_constantes.h"
#include "R3F_ARTY\dlg_artilleur\dlg_artilleur.h"
#include "R3F_ARTY\dlg_artilleur\dlg_chargeur.h"
#endif