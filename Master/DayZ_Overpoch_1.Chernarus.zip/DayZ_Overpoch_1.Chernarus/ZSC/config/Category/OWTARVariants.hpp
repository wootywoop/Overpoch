class Category_1003 {
class RH_ctar21 {type = "trade_weapons";buy[] = {40000,"Coins"};sell[] = {10000,"Coins"};};
class RH_ctar21glacog {type = "trade_weapons";buy[] = {40000,"Coins"};sell[] = {10000,"Coins"};};
class RH_ctar21m {type = "trade_weapons";buy[] = {40000,"Coins"};sell[] = {10000,"Coins"};};
class RH_ctar21mgl {type = "trade_weapons";buy[] = {40000,"Coins"};sell[] = {10000,"Coins"};};
};