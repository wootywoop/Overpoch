class Category_649 {
	class 15Rnd_W1866_Slug {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class 2Rnd_shotgun_74Pellets {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class 2Rnd_shotgun_74Slug {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class 8Rnd_B_Beneli_74Slug {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class 8Rnd_B_Beneli_Pellets {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class WoodenArrow {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class Quiver {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class 10x_303 {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
};
class Category_613 {
	class 15Rnd_W1866_Slug {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class 2Rnd_shotgun_74Pellets {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class 2Rnd_shotgun_74Slug {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class 8Rnd_B_Beneli_74Slug {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class 8Rnd_B_Beneli_Pellets {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class WoodenArrow {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class Quiver {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class 10x_303 {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
};
