class Category_529 {
	class HandGrenade_west {
		type = "trade_items";
		buy[] ={4000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class 1Rnd_HE_M203 {
		type = "trade_items";
		buy[] ={4000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class HandGrenade_east {
		type = "trade_items";
		buy[] ={4000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class PG7V {
		type = "trade_items";
		buy[] ={50000,"Coins"};
		sell[] ={10000,"Coins"};
	};
	class Dragon_EP1 {
		type = "trade_items";
		buy[] ={100000,"Coins"};
		sell[] ={22000,"Coins"};
	};
	class Javelin {
		type = "trade_items";
		buy[] ={200000,"Coins"};
		sell[] ={60000,"Coins"};
	};
	class Stinger {
		type = "trade_items";
		buy[] ={200000,"Coins"};
		sell[] ={62000,"Coins"};
	};
	class 6Rnd_HE_M203 {
		type = "trade_items";
		buy[] ={50000,"Coins"};
		sell[] ={12000,"Coins"};
	};
};
