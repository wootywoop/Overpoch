class Category_653 {
	class Ural_CDF {
		type = "trade_any_vehicle";
		buy[] ={20000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class Ural_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] ={20000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class Ural_UN_EP1 {
		type = "trade_any_vehicle";
		buy[] ={20000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class V3S_Open_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] ={20000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class V3S_Open_TK_EP1 {
		type = "trade_any_vehicle";
		buy[] ={20000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class Kamaz {
		type = "trade_any_vehicle";
		buy[] ={20000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class MTVR_DES_EP1 {
		type = "trade_any_vehicle";
		buy[] ={20000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class V3S_Civ {
		type = "trade_any_vehicle";
		buy[] ={20000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class V3S_TK_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] ={20000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class UralCivil_DZE {
		type = "trade_any_vehicle";
		buy[] ={20000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class UralCivil2_DZE {
		type = "trade_any_vehicle";
		buy[] ={10000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class KamazOpen_DZE {
		type = "trade_any_vehicle";
		buy[] ={20000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class MTVR {
		type = "trade_any_vehicle";
		buy[] ={20000,"Coins"};
		sell[] ={5000,"Coins"};
	};
};
class Category_586 {
	class Ural_CDF {
		type = "trade_any_vehicle";
		buy[] ={20000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class Ural_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] ={20000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class Ural_UN_EP1 {
		type = "trade_any_vehicle";
		buy[] ={20000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class V3S_Open_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] ={20000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class V3S_Open_TK_EP1 {
		type = "trade_any_vehicle";
		buy[] ={20000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class Kamaz {
		type = "trade_any_vehicle";
		buy[] ={20000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class MTVR_DES_EP1 {
		type = "trade_any_vehicle";
		buy[] ={20000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class V3S_Civ {
		type = "trade_any_vehicle";
		buy[] ={20000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class V3S_TK_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] ={20000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class UralCivil_DZE {
		type = "trade_any_vehicle";
		buy[] ={20000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class UralCivil2_DZE {
		type = "trade_any_vehicle";
		buy[] ={10000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class KamazOpen_DZE {
		type = "trade_any_vehicle";
		buy[] ={20000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class MTVR {
		type = "trade_any_vehicle";
		buy[] ={20000,"Coins"};
		sell[] ={5000,"Coins"};
	};
};
