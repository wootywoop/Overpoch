class Category_520 {
	class Skoda {
		type = "trade_any_vehicle";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class SkodaBlue {
		type = "trade_any_vehicle";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class SkodaGreen {
		type = "trade_any_vehicle";
		buy[] ={5000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class SkodaRed {
		type = "trade_any_vehicle";
		buy[] ={5000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class VolhaLimo_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] ={5000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class Volha_1_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] ={5000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class Volha_2_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] ={5000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class VWGolf {
		type = "trade_any_vehicle";
		buy[] ={6000,"Coins"};
		sell[] ={2500,"Coins"};
	};
	class car_hatchback {
		type = "trade_any_vehicle";
		buy[] ={5000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class car_sedan {
		type = "trade_any_vehicle";
		buy[] ={5000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class GLT_M300_LT {
		type = "trade_any_vehicle";
		buy[] ={5000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class GLT_M300_ST {
		type = "trade_any_vehicle";
		buy[] ={5000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class Lada1 {
		type = "trade_any_vehicle";
		buy[] ={5000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class Lada1_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] ={5000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class Lada2 {
		type = "trade_any_vehicle";
		buy[] ={5000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class Lada2_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] ={5000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class LadaLM {
		type = "trade_any_vehicle";
		buy[] ={5000,"Coins"};
		sell[] ={2000,"Coins"};
	};
};
