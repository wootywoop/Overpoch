class Category_569 {
	class HMMWV_M998A2_SOV_DES_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] ={400000,"Coins"};
		sell[] ={100000,"Coins"};
	};
	class HMMWV_M1151_M2_CZ_DES_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] ={300000,"Coins"};
		sell[] ={75000,"Coins"};
	};
	class LandRover_Special_CZ_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] ={100000,"Coins"};
		sell[] ={25000,"Coins"};
	};
	class LandRover_MG_TK_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] ={180000,"Coins"};
		sell[] ={45000,"Coins"};
	};
	class UAZ_MG_TK_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] ={200000,"Coins"};
		sell[] ={50000,"Coins"};
	};
	class GAZ_Vodnik_DZE {
		type = "trade_any_vehicle";
		buy[] ={500000,"Coins"};
		sell[] ={125000,"Coins"};
	};
	class GAZ_Vodnik_HMG {
		type = "trade_any_vehicle";
		buy[] ={1500000,"Coins"};
		sell[] ={375000,"Coins"};
	};
	class HMMWV_M2 {
		type = "trade_any_vehicle";
		buy[] ={30000,"Coins"};
		sell[] ={75000,"Coins"};
	};
	class HMMWV_Armored {
		type = "trade_any_vehicle";
		buy[] ={350000,"Coins"};
		sell[] ={87500,"Coins"};
	};
	class HMMWV_TOW {
		type = "trade_any_vehicle";
		buy[] ={600000,"Coins"};
		sell[] ={150000,"Coins"};
	};
	class HMMWV_Avenger {
		type = "trade_any_vehicle";
		buy[] ={1500000,"Coins"};
		sell[] ={375000,"Coins"};
	};
	class BRDM2_TK_EP1 {
		type = "trade_any_vehicle";
		buy[] ={2500000,"Coins"};
		sell[] ={625000,"Coins"};
	};
	class BRDM2_ATGM_TK_EP1 {
		type = "trade_any_vehicle";
		buy[] ={3000000,"Coins"};
		sell[] ={750000,"Coins"};
	};
	class T34 {
		type = "trade_any_vehicle";
		buy[] ={4000000,"Coins"};
		sell[] ={1000000,"Coins"};
	};
	class BTR90 {
		type = "trade_any_vehicle";
		buy[] ={5000000,"Coins"};
		sell[] ={1250000,"Coins"};
	};
	class BMP3 {
		type = "trade_any_vehicle";
		buy[] ={4500000,"Coins"};
		sell[] ={1125000,"Coins"};
	};
	class T55_TK_EP1 {
		type = "trade_any_vehicle";
		buy[] ={6000000,"Coins"};
		sell[] ={1500000,"Coins"};
	};
	class T72_CDF {
		type = "trade_any_vehicle";
		buy[] ={7000000,"Coins"};
		sell[] ={1750000,"Coins"};
	};
	class T90 {
		type = "trade_any_vehicle";
		buy[] ={9000000,"Coins"};
		sell[] ={2250000,"Coins"};
	};
	class BTR60_TK_EP1 {
		type = "trade_any_vehicle";
		buy[] ={10000000,"Coins"};
		sell[] ={2500000,"Coins"};
	};
	class ZSU_CDF {
		type = "trade_any_vehicle";
		buy[] ={5000000,"Coins"};
		sell[] ={1250000,"Coins"};
	};
	class MLRS {
		type = "trade_any_vehicle";
		buy[] ={14000000,"Coins"};
		sell[] ={3500000,"Coins"};
	};
};
