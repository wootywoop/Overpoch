class Category_1007 {
class RH_mas {type = "trade_weapons";buy[] = {40000,"Coins"};sell[] = {10000,"Coins"};};
class RH_masacog {type = "trade_weapons";buy[] = {40000,"Coins"};sell[] = {10000,"Coins"};};
class RH_masaim {type = "trade_weapons";buy[] = {40000,"Coins"};sell[] = {10000,"Coins"};};
class RH_masb {type = "trade_weapons";buy[] = {40000,"Coins"};sell[] = {10000,"Coins"};};
class RH_masbacog {type = "trade_weapons";buy[] = {40000,"Coins"};sell[] = {10000,"Coins"};};
class RH_masbaim {type = "trade_weapons";buy[] = {40000,"Coins"};sell[] = {10000,"Coins"};};
class RH_masbeotech {type = "trade_weapons";buy[] = {40000,"Coins"};sell[] = {10000,"Coins"};};
class RH_masbsd {type = "trade_weapons";buy[] = {40000,"Coins"};sell[] = {10000,"Coins"};};
class RH_masbsdacog {type = "trade_weapons";buy[] = {40000,"Coins"};sell[] = {10000,"Coins"};};
class RH_masbsdaim {type = "trade_weapons";buy[] = {40000,"Coins"};sell[] = {10000,"Coins"};};
class RH_masbsdeotech {type = "trade_weapons";buy[] = {40000,"Coins"};sell[] = {10000,"Coins"};};
class RH_maseotech {type = "trade_weapons";buy[] = {40000,"Coins"};sell[] = {10000,"Coins"};};
class RH_massd {type = "trade_weapons";buy[] = {40000,"Coins"};sell[] = {10000,"Coins"};};
class RH_massdacog {type = "trade_weapons";buy[] = {40000,"Coins"};sell[] = {10000,"Coins"};};
class RH_massdaim {type = "trade_weapons";buy[] = {40000,"Coins"};sell[] = {10000,"Coins"};};
class RH_massdeotech {type = "trade_weapons";buy[] = {40000,"Coins"};sell[] = {10000,"Coins"};};
};