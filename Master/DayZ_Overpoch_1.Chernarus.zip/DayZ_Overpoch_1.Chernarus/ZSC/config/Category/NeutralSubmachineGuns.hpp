class Category_642 {
class bizon_silenced {type = "trade_weapons";buy[] ={25000,"Coins"};sell[] ={7000,"Coins"};};
class UZI_EP1 {type = "trade_weapons";buy[] ={25000,"Coins"};sell[] ={7000,"Coins"};};
class Sa61_EP1 {type = "trade_weapons";buy[] ={20000,"Coins"};sell[] ={7500,"Coins"};};
class MP5A5 {type = "trade_weapons";buy[] ={30000,"Coins"};sell[] ={10000,"Coins"};};
class UZI_SD_EP1 {type = "trade_weapons";buy[] ={27500,"Coins"};sell[] ={7500,"Coins"};};
class MP5SD {type = "trade_weapons";buy[] ={30000,"Coins"};sell[] ={10000,"Coins"};};
};