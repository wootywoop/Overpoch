class Category_577 
{
class 30Rnd_556x45_StanagSD {type = "trade_items";buy[] ={400,"Coins"};sell[] ={200,"Coins"};};
class 5Rnd_86x70_L115A1 {type = "trade_items";buy[] ={4000,"Coins"};sell[] ={2000,"Coins"};};
class 100Rnd_762x51_M240 {type = "trade_items";buy[] ={2000,"Coins"};sell[] ={1000,"Coins"};};
class 20Rnd_762x51_FNFAL {type = "trade_items";buy[] ={400,"Coins"};sell[] ={200,"Coins"};};
class 20Rnd_762x51_SB_SCAR {type = "trade_items";buy[] ={1000,"Coins"};sell[] ={500,"Coins"};};
class 100Rnd_127x99_M2 {type = "trade_items";buy[] ={100000,"Coins"};sell[] ={50000,"Coins"};}; 
class 2000Rnd_762x51_L94A1 {type = "trade_items";buy[] ={100000,"Coins"};sell[] ={50000,"Coins"};}; 
class 32Rnd_40mm_GMG {type = "trade_items";buy[] ={100000,"Coins"};sell[] ={50000,"Coins"};}; 
class 48Rnd_40mm_MK19 {type = "trade_items";buy[] ={100000,"Coins"};sell[] ={50000,"Coins"};};
class 2000Rnd_762x51_M134 {type = "trade_items";buy[] ={100000,"Coins"};sell[] ={50000,"Coins"};}; 	
};
