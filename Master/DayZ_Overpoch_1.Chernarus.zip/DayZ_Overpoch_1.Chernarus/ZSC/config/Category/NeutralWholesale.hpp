class Category_636 {
	class bulk_15Rnd_9x19_M9SD {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class bulk_17Rnd_9x19_glock17 {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class bulk_30Rnd_556x45_StanagSD {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class bulk_30Rnd_9x19_MP5SD {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class bulk_ItemSandbag {
		type = "trade_items";
		buy[] ={18000,"Coins"};
		sell[] ={18000,"Coins"};
	};
	class bulk_ItemTankTrap {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={500,"Coins"};
	};
	class bulk_ItemWire {
		type = "trade_items";
		buy[] ={1000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class bulk_PartGeneric {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={500,"Coins"};
	};
	class CinderBlocks {
		type = "trade_items";
		buy[] ={10000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class PartPlywoodPack {
		type = "trade_items";
		buy[] ={600,"Coins"};
		sell[] ={300,"Coins"};
	};
	class MortarBucket {
		type = "trade_items";
		buy[] ={10000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class PartPlankPack {
		type = "trade_items";
		buy[] ={300,"Coins"};
		sell[] ={150,"Coins"};
	};
	class ItemFuelBarrelEmpty {
		type = "trade_items";
		buy[] ={3000,"Coins"};
		sell[] ={1500,"Coins"};
	};
};
