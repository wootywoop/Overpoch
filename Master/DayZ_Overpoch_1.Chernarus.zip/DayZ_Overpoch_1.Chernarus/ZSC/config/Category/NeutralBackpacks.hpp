class Category_685 {
	class DZ_Patrol_Pack_EP1 {
		type = "trade_backpacks";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class CZ_VestPouch_EP1 {
		type = "trade_backpacks";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class DZ_ALICE_Pack_EP1 {
		type = "trade_backpacks";
		buy[] ={3000,"Coins"};
		sell[] ={1500,"Coins"};
	};
	class DZ_Assault_Pack_EP1 {
		type = "trade_backpacks";
		buy[] ={3000,"Coins"};
		sell[] ={1500,"Coins"};
	};
	class DZ_Backpack_EP1 {
		type = "trade_backpacks";
		buy[] ={8000,"Coins"};
		sell[] ={4000,"Coins"};
	};
	class DZ_British_ACU {
		type = "trade_backpacks";
		buy[] ={4000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class DZ_CivilBackpack_EP1 {
		type = "trade_backpacks";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
	};
	class DZ_Czech_Vest_Puch {
		type = "trade_backpacks";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class DZ_TK_Assault_Pack_EP1 {
		type = "trade_backpacks";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class DZ_TerminalPack_EP1 {
		type = "trade_backpacks";
		buy[] ={600,"Coins"};
		sell[] ={300,"Coins"};
	};
	class DZ_GunBag_EP1 {
		type = "trade_backpacks";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
	};
};
class Category_496 {
	class DZ_Patrol_Pack_EP1 {
		type = "trade_backpacks";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class CZ_VestPouch_EP1 {
		type = "trade_backpacks";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class DZ_ALICE_Pack_EP1 {
		type = "trade_backpacks";
		buy[] ={3000,"Coins"};
		sell[] ={1500,"Coins"};
	};
	class DZ_Assault_Pack_EP1 {
		type = "trade_backpacks";
		buy[] ={3000,"Coins"};
		sell[] ={1500,"Coins"};
	};
	class DZ_Backpack_EP1 {
		type = "trade_backpacks";
		buy[] ={8000,"Coins"};
		sell[] ={4000,"Coins"};
	};
	class DZ_British_ACU {
		type = "trade_backpacks";
		buy[] ={4000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class DZ_CivilBackpack_EP1 {
		type = "trade_backpacks";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
	};
	class DZ_Czech_Vest_Puch {
		type = "trade_backpacks";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class DZ_TK_Assault_Pack_EP1 {
		type = "trade_backpacks";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class DZ_TerminalPack_EP1 {
		type = "trade_backpacks";
		buy[] ={600,"Coins"};
		sell[] ={300,"Coins"};
	};
	class DZ_GunBag_EP1 {
		type = "trade_backpacks";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
	};
};
class Category_632 {
	class DZ_Patrol_Pack_EP1 {
		type = "trade_backpacks";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class CZ_VestPouch_EP1 {
		type = "trade_backpacks";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class DZ_ALICE_Pack_EP1 {
		type = "trade_backpacks";
		buy[] ={3000,"Coins"};
		sell[] ={1500,"Coins"};
	};
	class DZ_Assault_Pack_EP1 {
		type = "trade_backpacks";
		buy[] ={3000,"Coins"};
		sell[] ={1500,"Coins"};
	};
	class DZ_Backpack_EP1 {
		type = "trade_backpacks";
		buy[] ={8000,"Coins"};
		sell[] ={4000,"Coins"};
	};
	class DZ_British_ACU {
		type = "trade_backpacks";
		buy[] ={4000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class DZ_CivilBackpack_EP1 {
		type = "trade_backpacks";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
	};
	class DZ_Czech_Vest_Puch {
		type = "trade_backpacks";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class DZ_TK_Assault_Pack_EP1 {
		type = "trade_backpacks";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class DZ_TerminalPack_EP1 {
		type = "trade_backpacks";
		buy[] ={600,"Coins"};
		sell[] ={300,"Coins"};
	};
	class DZ_GunBag_EP1 {
		type = "trade_backpacks";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
	};
};
