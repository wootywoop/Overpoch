class Category_605 {
class SVD_CAMO {type = "trade_weapons";buy[] ={67500,"Coins"};sell[] ={12000,"Coins"};};
class M40A3 {type = "trade_weapons";buy[] ={65000,"Coins"};sell[] ={15000,"Coins"};};
class M14_EP1 {type = "trade_weapons";buy[] ={60000,"Coins"};sell[] ={10000,"Coins"};};
class huntingrifle {type = "trade_weapons";buy[] ={40000,"Coins"};sell[] ={11000,"Coins"};};
class M4SPR {type = "trade_weapons";buy[] ={60000,"Coins"};sell[] ={12000,"Coins"};};
class SVD {type = "trade_weapons";buy[] ={65000,"Coins"};sell[] ={10000,"Coins"};};
class SVD_des_EP1 {type = "trade_weapons";buy[] ={65000,"Coins"};sell[] ={10000,"Coins"};};
class M24 {type = "trade_weapons";buy[] ={65000,"Coins"};sell[] ={10000,"Coins"};};
class M24_des_EP1 {type = "trade_weapons";buy[] ={65000,"Coins"};sell[] ={10000,"Coins"};};
};
class Category_640 {
class SVD_CAMO {type = "trade_weapons";buy[] ={67500,"Coins"};sell[] ={12000,"Coins"};};
class M40A3 {type = "trade_weapons";buy[] ={65000,"Coins"};sell[] ={15000,"Coins"};};
class M14_EP1 {type = "trade_weapons";buy[] ={60000,"Coins"};sell[] ={10000,"Coins"};};
class huntingrifle {type = "trade_weapons";buy[] ={40000,"Coins"};sell[] ={11000,"Coins"};};
class M4SPR {type = "trade_weapons";buy[] ={60000,"Coins"};sell[] ={12000,"Coins"};};
class SVD {type = "trade_weapons";buy[] ={65000,"Coins"};sell[] ={10000,"Coins"};};
class SVD_des_EP1 {type = "trade_weapons";buy[] ={65000,"Coins"};sell[] ={10000,"Coins"};};
class M24 {type = "trade_weapons";buy[] ={65000,"Coins"};sell[] ={10000,"Coins"};};
class M24_des_EP1 {type = "trade_weapons";buy[] ={65000,"Coins"};sell[] ={10000,"Coins"};};
};
