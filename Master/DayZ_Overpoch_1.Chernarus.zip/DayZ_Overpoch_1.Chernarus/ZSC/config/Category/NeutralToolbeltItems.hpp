
class Category_510 {
	class ItemCompass {
		type = "trade_weapons";
		buy[] ={200,"Coins"};
		sell[] ={100,"Coins"};
	};
	class Binocular {
		type = "trade_weapons";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class Binocular_Vector {
		type = "trade_weapons";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class ItemEtool {
		type = "trade_weapons";
		buy[] = {3000,"Coins"};
		sell[] ={1500,"Coins"};
	};
	class ItemFlashlight {
		type = "trade_weapons";
		buy[] ={60,"Coins"};
		sell[] ={1,"Coins"};
	};
	class ItemFlashlightRed {
		type = "trade_weapons";
		buy[] ={300,"Coins"};
		sell[] ={150,"Coins"};
	};
	class ItemGPS {
		type = "trade_weapons";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class ItemHatchet_DZE {
		type = "trade_weapons";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class ItemKnife {
		type = "trade_weapons";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class ItemMap {
		type = "trade_weapons";
		buy[] ={180,"Coins"};
		sell[] ={1,"Coins"};
	};
	class ItemMatchbox_DZE {
		type = "trade_weapons";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class ItemToolbox {
		type = "trade_weapons";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class ItemWatch {
		type = "trade_weapons";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class NVGoggles {
		type = "trade_weapons";
		buy[] ={4000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class ItemCrowbar {
		type = "trade_weapons";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class ItemMachete {
		type = "trade_weapons";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class ItemFishingPole {
		type = "trade_weapons";
		buy[] ={600,"Coins"};
		sell[] ={300,"Coins"};
	};
};
