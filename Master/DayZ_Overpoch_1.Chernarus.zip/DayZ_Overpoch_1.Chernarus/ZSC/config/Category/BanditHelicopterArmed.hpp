class Category_512 {
		class CH_47F_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] ={400000,"Coins"};
		sell[] ={100000,"Coins"};
	};
	class UH1H_DZE {
		type = "trade_any_vehicle";
		buy[] ={200000,"Coins"};
		sell[] ={70000,"Coins"};
	};
	class Mi17_DZE {
		type = "trade_any_vehicle";
		buy[] ={200000,"Coins"};
		sell[] ={80000,"Coins"};
	};
	class Mi17_CDF {
		type = "trade_any_vehicle";
		buy[] ={200000,"Coins"};
		sell[] ={80000,"Coins"};
	};
	class Mi17_Ins {
		type = "trade_any_vehicle";
		buy[] ={200000,"Coins"};
		sell[] ={75000,"Coins"};
	};
	class UH60M_EP1_DZE {
		type = "trade_any_vehicle";
		buy[] ={200000,"Coins"};
		sell[] ={80000,"Coins"};
	};
	class UH1Y_DZE {
		type = "trade_any_vehicle";
		buy[] ={200000,"Coins"};
		sell[] ={90000,"Coins"};
	};
	class MH60S_DZE {
		type = "trade_any_vehicle";
		buy[] ={400000,"Coins"};
		sell[] ={85000,"Coins"};
	};
	class UH1Y {
		type = "trade_any_vehicle";
		buy[] ={300000,"Coins"};
		sell[] ={75000,"Coins"};
	};
	class Ka52Black {
		type = "trade_any_vehicle";
		buy[] ={6500000,"Coins"};
		sell[] ={3300000,"Coins"};
	};
	class Ka52 {
		type = "trade_any_vehicle";
		buy[] ={6500000,"Coins"};
		sell[] ={3300000,"Coins"};
	};
	class Mi24_V {
		type = "trade_any_vehicle";
		buy[] ={5000000,"Coins"};
		sell[] ={2500000,"Coins"};
	};
	class Mi24_P {
		type = "trade_any_vehicle";
		buy[] ={5000000,"Coins"};
		sell[] ={2500000,"Coins"};
	};
	class Mi24_D {
		type = "trade_any_vehicle";
		buy[] ={5000000,"Coins"};
		sell[] ={2500000,"Coins"};
	};
	class AH1Z {
		type = "trade_any_vehicle";
		buy[] ={6500000,"Coins"};
		sell[] ={3300000,"Coins"};
	};
};