class Category_662 {
	class ItemSandbag {
		type = "trade_items";
		buy[] ={4000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class storage_shed_kit {
		type = "trade_items";
		buy[] ={11000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class wooden_shed_kit {
		type = "trade_items";
		buy[] ={11000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class metal_panel_kit {
		type = "trade_items";
		buy[] ={5000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class metal_floor_kit {
		type = "trade_items";
		buy[] ={20000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class fuel_pump_kit {
		type = "trade_items";
		buy[] ={300000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class CinderBlocks {
		type = "trade_items";
		buy[] ={15000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class MortarBucket {
		type = "trade_items";
		buy[] ={15000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class cinder_wall_kit {
		type = "trade_items";
		buy[] ={65000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class cinder_garage_kit {
		type = "trade_items";
		buy[] ={66000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class cinder_door_kit {
		type = "trade_items";
		buy[] ={77000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class ItemCorrugated {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class ItemPole {
		type = "trade_items";
		buy[] ={300,"Coins"};
		sell[] ={150,"Coins"};
	};
	class ItemSledge {
		type = "trade_items";
		buy[] ={5000,"Coins"};
		sell[] ={150,"Coins"};
	};
	class ItemTankTrap {
		type = "trade_items";
		buy[] ={600,"Coins"};
		sell[] ={150,"Coins"};
	};
	class ItemTentOld {
		type = "trade_items";
		buy[] ={1200,"Coins"};
		sell[] ={600,"Coins"};
	};
	class ItemWire {
		type = "trade_items";
		buy[] ={180,"Coins"};
		sell[] ={90,"Coins"};
	};
	class 30m_plot_kit {
		type = "trade_items";
		buy[] ={60000,"Coins"};
		sell[] ={40000,"Coins"};
	};
	class ItemVault {
		type = "trade_items";
		buy[] ={100000,"Coins"};
		sell[] ={100000,"Coins"};
	};
	class ItemHotwireKit {
		type = "trade_items";
		buy[] ={500000,"Coins"};
		sell[] ={100000,"Coins"};
	};
	class ItemTentDomed {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class ItemTentDomed2 {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class ItemLightBulb {
		type = "trade_items";
		buy[] ={600,"Coins"};
		sell[] ={300,"Coins"};
	};
	class ItemGenerator {
		type = "trade_items";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
        };
    class ItemComboLock {
		type = "trade_items";
		buy[] ={10000,"Coins"};
		sell[] ={5000,"Coins"};
	};
      class ItemLockbox {
	    type = "trade_items";
		buy[] ={40000,"Coins"};
		sell[] ={20000,"Coins"};
	};
	 class ChainSaw {
	    type = "trade_weapons";
		buy[] ={60000,"Coins"};
		sell[] ={10000,"Coins"};
	};
		class ChainSawB {
	    type = "trade_weapons";
		buy[] ={60000,"Coins"};
		sell[] ={10000,"Coins"};
	};
		 class ChainSawG {
	    type = "trade_weapons";
		buy[] ={60000,"Coins"};
		sell[] ={10000,"Coins"};
	};
		 class ChainSawP {
	    type = "trade_weapons";
		buy[] ={60000,"Coins"};
		sell[] ={10000,"Coins"};
	};
		 class ChainSawR {
	    type = "trade_weapons";
		buy[] ={60000,"Coins"};
		sell[] ={10000,"Coins"};
	};
	 class ItemMixOil {
	    type = "trade_items";
		buy[] ={5000,"Coins"};
		sell[] ={2500,"Coins"};
	};
};
class Category_508 {
	class ItemSandbag {
		type = "trade_items";
		buy[] ={4000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class storage_shed_kit {
		type = "trade_items";
		buy[] ={11000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class wooden_shed_kit {
		type = "trade_items";
		buy[] ={11000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class metal_panel_kit {
		type = "trade_items";
		buy[] ={5000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class metal_floor_kit {
		type = "trade_items";
		buy[] ={20000,"Coins"};
		sell[] ={2000,"Coins"};
	};
	class fuel_pump_kit {
		type = "trade_items";
		buy[] ={300000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class CinderBlocks {
		type = "trade_items";
		buy[] ={15000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class MortarBucket {
		type = "trade_items";
		buy[] ={15000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class cinder_wall_kit {
		type = "trade_items";
		buy[] ={65000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class cinder_garage_kit {
		type = "trade_items";
		buy[] ={66000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class cinder_door_kit {
		type = "trade_items";
		buy[] ={77000,"Coins"};
		sell[] ={5000,"Coins"};
	};
	class ItemCorrugated {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class ItemPole {
		type = "trade_items";
		buy[] ={300,"Coins"};
		sell[] ={150,"Coins"};
	};
	class ItemSledge {
		type = "trade_items";
		buy[] ={5000,"Coins"};
		sell[] ={150,"Coins"};
	};
	class ItemTankTrap {
		type = "trade_items";
		buy[] ={600,"Coins"};
		sell[] ={150,"Coins"};
	};
	class ItemTentOld {
		type = "trade_items";
		buy[] ={1200,"Coins"};
		sell[] ={600,"Coins"};
	};
	class ItemWire {
		type = "trade_items";
		buy[] ={180,"Coins"};
		sell[] ={90,"Coins"};
	};
	class 30m_plot_kit {
		type = "trade_items";
		buy[] ={60000,"Coins"};
		sell[] ={40000,"Coins"};
	};
	class ItemVault {
		type = "trade_items";
		buy[] ={100000,"Coins"};
		sell[] ={100000,"Coins"};
	};
	class ItemTentDomed {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class ItemTentDomed2 {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class ItemLightBulb {
		type = "trade_items";
		buy[] ={600,"Coins"};
		sell[] ={300,"Coins"};
	};
	class ItemGenerator {
		type = "trade_items";
		buy[] ={6000,"Coins"};
		sell[] ={3000,"Coins"};
        };
    class ItemComboLock {
		type = "trade_items";
		buy[] ={10000,"Coins"};
		sell[] ={5000,"Coins"};
	};
      class ItemLockbox {
	    type = "trade_items";
		buy[] ={40000,"Coins"};
		sell[] ={20000,"Coins"};
	};
	 class ChainSaw {
	    type = "trade_weapons";
		buy[] ={60000,"Coins"};
		sell[] ={10000,"Coins"};
	};
		class ChainSawB {
	    type = "trade_weapons";
		buy[] ={60000,"Coins"};
		sell[] ={10000,"Coins"};
	};
		 class ChainSawG {
	    type = "trade_weapons";
		buy[] ={60000,"Coins"};
		sell[] ={10000,"Coins"};
	};
		 class ChainSawP {
	    type = "trade_weapons";
		buy[] ={60000,"Coins"};
		sell[] ={10000,"Coins"};
	};
		 class ChainSawR {
	    type = "trade_weapons";
		buy[] ={60000,"Coins"};
		sell[] ={10000,"Coins"};
	};
	 class ItemMixOil {
	    type = "trade_items";
		buy[] ={5000,"Coins"};
		sell[] ={2500,"Coins"};
	};
};
