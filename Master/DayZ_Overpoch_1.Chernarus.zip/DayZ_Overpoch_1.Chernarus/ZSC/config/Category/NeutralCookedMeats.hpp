class Category_686 {
	class FoodbaconCooked {
		type = "trade_items";
		buy[] ={120,"Coins"};
		sell[] ={60,"Coins"};
	};
	class FoodbeefCooked {
		type = "trade_items";
		buy[] ={120,"Coins"};
		sell[] ={60,"Coins"};
	};
	class FoodchickenCooked {
		type = "trade_items";
		buy[] ={120,"Coins"};
		sell[] ={60,"Coins"};
	};
	class FoodmuttonCooked {
		type = "trade_items";
		buy[] ={120,"Coins"};
		sell[] ={60,"Coins"};
	};
	class FoodrabbitCooked {
		type = "trade_items";
		buy[] ={600,"Coins"};
		sell[] ={300,"Coins"};
	};
	class ItemTroutCooked {
		type = "trade_items";
		buy[] ={1000,"Coins"};
		sell[] ={500,"Coins"};
	};
	class ItemSeaBassCooked {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class ItemTunaCooked {
		type = "trade_items";
		buy[] ={3000,"Coins"};
		sell[] ={1500,"Coins"};
	};
};
class Category_580 {
	class FoodbaconCooked {
		type = "trade_items";
		buy[] ={120,"Coins"};
		sell[] ={60,"Coins"};
	};
	class FoodbeefCooked {
		type = "trade_items";
		buy[] ={120,"Coins"};
		sell[] ={60,"Coins"};
	};
	class FoodchickenCooked {
		type = "trade_items";
		buy[] ={120,"Coins"};
		sell[] ={60,"Coins"};
	};
	class FoodmuttonCooked {
		type = "trade_items";
		buy[] ={120,"Coins"};
		sell[] ={60,"Coins"};
	};
	class FoodrabbitCooked {
		type = "trade_items";
		buy[] ={600,"Coins"};
		sell[] ={300,"Coins"};
	};
	class ItemTroutCooked {
		type = "trade_items";
		buy[] ={1000,"Coins"};
		sell[] ={500,"Coins"};
	};
	class ItemSeaBassCooked {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class ItemTunaCooked {
		type = "trade_items";
		buy[] ={3000,"Coins"};
		sell[] ={1500,"Coins"};
	};
};
class Category_634 {
	class FoodbaconCooked {
		type = "trade_items";
		buy[] ={120,"Coins"};
		sell[] ={60,"Coins"};
	};
	class FoodbeefCooked {
		type = "trade_items";
		buy[] ={120,"Coins"};
		sell[] ={60,"Coins"};
	};
	class FoodchickenCooked {
		type = "trade_items";
		buy[] ={120,"Coins"};
		sell[] ={60,"Coins"};
	};
	class FoodmuttonCooked {
		type = "trade_items";
		buy[] ={120,"Coins"};
		sell[] ={60,"Coins"};
	};
	class FoodrabbitCooked {
		type = "trade_items";
		buy[] ={600,"Coins"};
		sell[] ={300,"Coins"};
	};
	class ItemTroutCooked {
		type = "trade_items";
		buy[] ={1000,"Coins"};
		sell[] ={500,"Coins"};
	};
	class ItemSeaBassCooked {
		type = "trade_items";
		buy[] ={2000,"Coins"};
		sell[] ={1000,"Coins"};
	};
	class ItemTunaCooked {
		type = "trade_items";
		buy[] ={3000,"Coins"};
		sell[] ={1500,"Coins"};
	};
};
