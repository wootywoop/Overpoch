class Category_668 {
	class SmokeShell {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class SmokeShellGreen {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class SmokeShellRed {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
};
class Category_671 {
	class SmokeShell {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class SmokeShellGreen {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
	class SmokeShellRed {
		type = "trade_items";
		buy[] ={60,"Coins"};
		sell[] ={30,"Coins"};
	};
};
