/*
	DZAI Version Identifier File
*/

#define DZAI_CLIENT_TYPE "DZAI Client Addon"
#define DZAI_CLIENT_VERSION "1.0.0"
