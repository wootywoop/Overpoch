class Category_701 {
	class UAZ_MG_CDF {
		type = "trade_any_vehicle";
		buy[] ={300000,"Coins"};
		sell[] ={40000,"Coins"};
	};
	class HMMWV_M1151_M2_DES_EP1 {
		type = "trade_any_vehicle";
		buy[] ={300000,"Coins"};
		sell[] ={40000,"Coins"};
	};
	class LAV25 {
		type = "trade_any_vehicle";
		buy[] ={5500000,"Coins"};
		sell[] ={1000000,"Coins"};
	};
	class BRDM2_CDF {
		type = "trade_any_vehicle";
		buy[] ={3500000,"Coins"};
		sell[] ={500000,"Coins"};
	};
	class BMP2_Ambul_CDF {
		type = "trade_any_vehicle";
		buy[] ={1500000,"Coins"};
		sell[] ={400000,"Coins"};
	};
	class GAZ_Vodnik_MedEvac {
		type = "trade_any_vehicle";
		buy[] ={200000,"Coins"};
		sell[] ={20000,"Coins"};
	};
	class Ural_TK_CIV_EP1 {
		type = "trade_any_vehicle";
		buy[] ={20000,"Coins"};
		sell[] ={10000,"Coins"};
	};
};
