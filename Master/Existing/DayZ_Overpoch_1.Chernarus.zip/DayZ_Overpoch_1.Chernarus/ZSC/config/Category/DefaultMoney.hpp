class Category_700 {
	class ItemBriefcase100oz {
		type = "trade_items";
		buy[] ={100000,"Coins"};
		sell[] ={90000,"Coins"};
	};
	
	class CDF_dogtags {
		type = "trade_weapons";
		buy[] ={155938,"Coins"};
		sell[] ={0,"Coins"};
	};
	
	class Cobalt_File {
		type = "trade_weapons";
		buy[] ={781250,"Coins"};
		sell[] ={0,"Coins"};
	};
	
	class PMC_documents {
		type = "trade_weapons";
		buy[] ={1562188,"Coins"};
		sell[] ={0,"Coins"};
	};
	
	class Moscow_Bombing_File {
		type = "trade_weapons";
		buy[] ={3125000,"Coins"};
		sell[] ={0,"Coins"};
	};
	
	class Kostey_notebook {
		type = "trade_weapons";
		buy[] ={6250000,"Coins"};
		sell[] ={0,"Coins"};
	};
	
	class EvPhoto {
		type = "trade_weapons";
		buy[] ={3500000,"Coins"};
		sell[] ={0,"Coins"};
	};
	
	class ItemGoldBar {
		type = "trade_items";
		buy[] ={1000,"Coins"};
		sell[] ={900,"Coins"};
	};
	class ItemGoldBar10oz {
		type = "trade_items";
		buy[] ={10000,"Coins"};
		sell[] ={9000,"Coins"};
	};
	class ItemSilverBar {
		type = "trade_items";
		buy[] ={10,"Coins"};
		sell[] ={10,"Coins"};
	};
	class ItemSilverBar10oz {
		type = "trade_items";
		buy[] ={100,"Coins"};
		sell[] ={100,"Coins"};
	};
	class ItemCopperBar10oz {
		type = "trade_items";
		buy[] ={1,"Coins"};
		sell[] ={1,"Coins"};
	};
	class ItemTinBar {
		type = "trade_items";
		buy[] ={2,"Coins"};
		sell[] ={2,"Coins"};
	};
    class ItemAluminumBar {
	    type = "trade_items";                 
		buy[] ={2,"Coins"};
		sell[] ={2,"Coins"};
       };
	
	class ItemObsidian{
	    type = "trade_items";                 
		buy[] ={100000,"Coins"};
		sell[] ={90000,"Coins"};
       };
	   
	class ItemSapphire{
	    type = "trade_items";                 
		buy[] ={100000,"Coins"};
		sell[] ={90000,"Coins"};
       };
 
	class ItemAmethyst{
	    type = "trade_items";                 
		buy[] ={100000,"Coins"};
		sell[] ={90000,"Coins"};
       };
 
	class ItemEmerald{
	    type = "trade_items";                 
		buy[] ={100000,"Coins"};
		sell[] ={90000,"Coins"};
       };
 
	class ItemCitrine{
	    type = "trade_items";                 
		buy[] ={100000,"Coins"};
		sell[] ={90000,"Coins"};
       };
	   
	class ItemTopaz{
	    type = "trade_items";                 
		buy[] ={100000,"Coins"};
		sell[] ={90000,"Coins"};
      };
	
	class ItemRuby{
	    type = "trade_items";                 
		buy[] ={100000,"Coins"};
		sell[] ={90000,"Coins"};
      };
 
    class PartOre {
	    type = "trade_items";                 
		buy[] ={20,"Coins"};
		sell[] ={20,"Coins"};
       };
	   
	class PartOreSilver {
	    type = "trade_items";                 
		buy[] ={30,"Coins"};
		sell[] ={30,"Coins"};
       };
	   
	class PartOreGold {
	    type = "trade_items";                 
		buy[] ={1000,"Coins"};
		sell[] ={1000,"Coins"};
       };
};