class Category_1016 {
class 350z {type = "trade_any_vehicle";buy[] = {80000,"Coins"};sell[] = {20000,"Coins"};};
class 350z_red {type = "trade_any_vehicle";buy[] = {80000,"Coins"};sell[] = {20000,"Coins"};};
class 350z_kiwi {type = "trade_any_vehicle";buy[] = {80000,"Coins"};sell[] = {20000,"Coins"};};
class 350z_black {type = "trade_any_vehicle";buy[] = {80000,"Coins"};sell[] = {20000,"Coins"};};
class 350z_silver {type = "trade_any_vehicle";buy[] = {80000,"Coins"};sell[] = {20000,"Coins"};};
class 350z_green {type = "trade_any_vehicle";buy[] = {80000,"Coins"};sell[] = {20000,"Coins"};};
class 350z_blue {type = "trade_any_vehicle";buy[] = {80000,"Coins"};sell[] = {20000,"Coins"};};
class 350z_gold {type = "trade_any_vehicle";buy[] = {80000,"Coins"};sell[] = {20000,"Coins"};};
class 350z_white {type = "trade_any_vehicle";buy[] = {80000,"Coins"};sell[] = {20000,"Coins"};};
class 350z_pink {type = "trade_any_vehicle";buy[] = {80000,"Coins"};sell[] = {20000,"Coins"};};
class 350z_mod {type = "trade_any_vehicle";buy[] = {80000,"Coins"};sell[] = {20000,"Coins"};};
class 350z_ruben {type = "trade_any_vehicle";buy[] = {80000,"Coins"};sell[] = {20000,"Coins"};};
class 350z_v {type = "trade_any_vehicle";buy[] = {80000,"Coins"};sell[] = {20000,"Coins"};};
class 350z_city {type = "trade_any_vehicle";buy[] = {80000,"Coins"};sell[] = {20000,"Coins"};};
class 350z_yellow {type = "trade_any_vehicle";buy[] = {80000,"Coins"};sell[] = {20000,"Coins"};};
};