class Category_647 {
	class 20Rnd_762x51_DMR {
		type = "trade_items";
		buy[] ={200,"Coins"};
		sell[] ={100,"Coins"};
	};
	class 10Rnd_762x54_SVD {
		type = "trade_items";
		buy[] ={200,"Coins"};
		sell[] ={100,"Coins"};
	};
	class 5Rnd_762x51_M24 {
		type = "trade_items";
		buy[] ={100,"Coins"};
		sell[] ={50,"Coins"};
	};
	class 5x_22_LR_17_HMR {
		type = "trade_items";
		buy[] ={200,"Coins"};
		sell[] ={100,"Coins"};
	};
};
class Category_614 {
	class 20Rnd_762x51_DMR {
		type = "trade_items";
		buy[] ={200,"Coins"};
		sell[] ={100,"Coins"};
	};
	class 10Rnd_762x54_SVD {
		type = "trade_items";
		buy[] ={200,"Coins"};
		sell[] ={100,"Coins"};
	};
	class 5Rnd_762x51_M24 {
		type = "trade_items";
		buy[] ={100,"Coins"};
		sell[] ={50,"Coins"};
	};
	class 5x_22_LR_17_HMR {
		type = "trade_items";
		buy[] ={200,"Coins"};
		sell[] ={100,"Coins"};
	};
};
